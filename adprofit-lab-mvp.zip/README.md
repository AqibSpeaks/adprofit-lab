# AdProfit Lab — $0 static SaaS validation MVP

## Run locally
Open `index.html` in a browser or run `python3 -m http.server 8000` in this directory and open http://localhost:8000.

## Deploy to GitHub Pages
1. Create a **public** GitHub repository, for example `adprofit-lab` (check GitHub's current free Pages eligibility).
2. Upload **all** project files, including `.github/workflows/deploy.yml`, to the `main` branch.
3. In repository Settings → Pages, set Source to **GitHub Actions**.
4. Push a change to `main` or trigger the workflow from Actions. The Pages URL appears in the workflow deployment and Settings → Pages.
5. In `index.html`, replace `YOUR_EMAIL@example.com` with your business email before publishing. This is a `mailto:` interest link, not a stored waitlist.
6. Test all five tools on desktop and mobile and review the privacy wording before sharing.

## Monetization reality
The $9/month Pro tier is **planned** and cannot be purchased in this MVP. Do not accept payments before you have an approved payment provider, terms, refund policy, customer support, and a secure server-side billing integration. For Pakistan-based founders, verify the provider supports your country and legal entity before choosing it. Never place secret payment keys in static JavaScript.

## Growth workflow ($0)
- Weekly: use Search Console to identify useful high-intent calculator searches; draft one human-reviewed explanatory page.
- Weekly: publish educational posts linking to a relevant tool, without making performance promises.
- Track unique visitors, tool interactions, qualified Pro inquiries, and conversion to paid **once billing is live**.
- Only add AI API calls through a server-side function with authentication, rate limits, abuse prevention, and spending caps. A client-only app cannot safely keep API keys private.

## Production roadmap
1. Validate demand: aim for 10 qualified early-access inquiries (not a guaranteed result).
2. Add hosted authentication and database (e.g. Supabase free tier subject to current limits), with row-level security and privacy policy.
3. Integrate a supported billing provider using hosted checkout and verified server-side webhooks; do not trust client-reported payments.
4. Build subscriber entitlements, cancellations, and receipts.
5. Add API-powered ad copy generation using server-side secrets, cost caps, and abuse controls.
6. Add scheduled reporting through GitHub Actions or a backend scheduler, and email only opted-in users.

## Calculation definitions
- ROAS = revenue / ad spend; undefined if spend is zero.
- Net profit = revenue - ad spend - cost of goods/fulfillment - other costs (before tax).
- Break-even ad CPA = average order value - variable costs/order - other acquisition costs/order. Negative value means an order is unprofitable before ads.
- Estimated acquisitions = budget / target CPA, assuming target CPA is actually achieved.

## Security
No analytics, tracking, API calls, accounts, or persistence are included. Calculations are browser-local. Review legal/privacy requirements before adding tracking or emails.
